package com.thangam.assessment.employee;

import java.util.Date;

import com.thangam.assessment.employee.EmployeeEntity.CitizenshipType;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class EmployeeDto {
    private Long id;
    
    private String firstName;
    
    private String lastName;
    
    private String middleName;
    
    private String lastNameOther;
    
    private String address;
    
    private int apartmentNumber;
    
    private String city;
    
    private String state;
    
    private String zipCode;
    
    private Date dateOfBirth;
    
    private String socialSecurityNumber;
    
    private String email;
    
    private String phone;
    
    private CitizenshipType citizenshipType;
    
    private Date expirationDate;
    
    private String alienRegistrationNumber;
    
    private String formI94AdmissionNumber;
    
    private String foreignPassportNumber;
    
    private String countryOfIssuance;
    
    private Date createdAt;
    
    private Date updatedAt;
}
