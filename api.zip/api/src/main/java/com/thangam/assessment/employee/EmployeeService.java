package com.thangam.assessment.employee;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.vavr.control.Option;
import io.vavr.control.Try;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    private EmployeeMapper employeeMapper;
    
    public Try<Long> save(EmployeeDto employeeDto) {
        EmployeeEntity employeeEntity = employeeMapper.dtoToEntity(employeeDto);
        return Option.of(employeeRepository.save(employeeEntity))
                .toTry(() -> new Exception("Failed to save"))
                .map(EmployeeEntity::getId);
    }
    
    public List<EmployeeDto> getAll() {
        List<EmployeeEntity> employees = employeeRepository.findAll();
        if(employees.isEmpty()) {
            return Collections.emptyList();
        } else {
            return employeeMapper.entitiesTodtos(employees);
        }
    }
}
