package com.thangam.assessment.employee;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "employee")
public class EmployeeEntity {
    @Id
    @GeneratedValue(generator = "employee_generator")
    @SequenceGenerator(
            name = "employee_generator",
            sequenceName = "employee_sequence",
            initialValue = 5
    )
    private Long id;
    @Column
    private String firstName;
    @Column
    private String lastName;
    @Column
    private String middleName;
    @Column
    private String lastNameOther;
    @Column
    private String address;
    @Column
    private int apartmentNumber;
    @Column
    private String city;
    @Column
    private String state;
    @Column
    private String zipCode;
    @Column
    private Date dateOfBirth;
    @Column
    private String socialSecurityNumber;
    @Column
    private String email;
    @Column
    private String phone;
    @Column
    private CitizenshipType citizenshipType;
    @Column
    private Date expirationDate;
    @Column
    private String alienRegistrationNumber;
    @Column
    private String formI94AdmissionNumber;
    @Column
    private String foreignPassportNumber;
    @Column
    private String countryOfIssuance;
    @Column
    private Date createdAt;
    @Column
    private Date updatedAt;

    @PrePersist
    public void setCreatedDate() {
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }
    
    @PreUpdate
    public void setUpdatedDate() {
        this.updatedAt = new Date();
    }
    
    public enum CitizenshipType {
        UNITED_STATES_CITIZEN, NON_CITIZEN_NATIONAL_OF_THE_UNITED_STATES, LAWFUL_PERMANENT_RESIDENT, ALIEN
    }
}
