package com.thangam.assessment.exception;

import static io.vavr.API.$;
import static io.vavr.API.Case;
import static io.vavr.API.Match;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.ResponseEntity.status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;

public class HandleException {
    private static Logger logger = LoggerFactory.getLogger(HandleException.class);
    
    public static ResponseEntity handleException(Throwable exception) {
        logger.trace(String.format("Exception Occured", exception.getMessage()));
        return Match(exception).of(
                Case($(), status(INTERNAL_SERVER_ERROR).body(exception.getMessage()))
        );
    }
}
