package com.thangam.assessment.employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.thangam.assessment.exception.HandleException;

@CrossOrigin("*")
@RestController
@RequestMapping("api/employee")
@Controller
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;
    
    @PostMapping()
    public ResponseEntity<Long> save(@RequestBody @Validated EmployeeDto employeeDto) {
        return employeeService.save(employeeDto)
                .map(result -> ResponseEntity.ok().body(result))
                .getOrElseGet(HandleException::handleException);
    }
    
    @GetMapping()
    public List<EmployeeDto> getAll() {
        return employeeService.getAll();
    }
}
