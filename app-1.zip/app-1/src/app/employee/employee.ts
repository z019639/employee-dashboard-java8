export class Employee {
  id: number = null;
  firstName:string = '';
  lastName: string = '';
  middleName: string = '';
  lastNameOther: string = '';
  address: string = '';
  apartmentNumber = 0;
  city: string = '';
  state: string = '';
  zipCode: string = '';
  dateOfBirth: Date = null
  socialSecurityNumber: string = '';
  email: string = '';
  phone: string = '';
  citizenshipType: CitizenshipType = null;
  expirationDate: Date = null;
  alienRegistrationNumber: string = '';
  formI94AdmissionNumber: string = '';
  foreignPassportNumber: string = '';
  countryOfIssuance: string = '';
  createdAt: Date;
  updatedAt: Date;
}

export enum CitizenshipType {
  UNITED_STATES_CITIZEN,
  NON_CITIZEN_NATIONAL_OF_THE_UNITED_STATES,
  LAWFUL_PERMANENT_RESIDENT,
  ALIEN
}