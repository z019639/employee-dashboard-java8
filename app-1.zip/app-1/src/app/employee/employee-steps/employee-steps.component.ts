import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-steps',
  templateUrl: './employee-steps.component.html',
  styleUrls: ['./employee-steps.component.scss']
})
export class EmployeeStepsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
