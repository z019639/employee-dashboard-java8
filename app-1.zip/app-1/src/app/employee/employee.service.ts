import {HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import {environment} from '../../environments/environment';
import {Employee} from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  basePath = environment.baseURL;

  constructor(private httpClient: HttpClient) { }

  public addOrUpdate(employee: Employee): Promise<any> {
    return this.httpClient.post<any>(`${this.basePath}/employee`, employee).toPromise();
  }
}
