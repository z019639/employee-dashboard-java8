import { Component } from '@angular/core';
import {NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {CitizenshipType, Employee} from './employee';
import {EmployeeService} from './employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']
})
export class EmployeeComponent{
  employee = new Employee();
  dateOfBirth: NgbDateStruct;
  expiryDate: NgbDateStruct;
  hasMissingAlienField: boolean = false;
  CitizenshipType = CitizenshipType;

  constructor(private employeeService: EmployeeService, private toastrService: ToastrService) { }

  onChangeCitizenship(citizenshipType: CitizenshipType): void {
    this.employee.citizenshipType = citizenshipType;
    if (citizenshipType !== CitizenshipType.LAWFUL_PERMANENT_RESIDENT && citizenshipType !== CitizenshipType.ALIEN) {
      this.employee.alienRegistrationNumber = '';
    }
    if (citizenshipType !== CitizenshipType.ALIEN) {
      this.employee.formI94AdmissionNumber = '';
      this.employee.foreignPassportNumber = '';
      this.employee.countryOfIssuance = '';
    } else {
      this.hasMissingAlienField = true;
    }
  }

  onChangeDateOfBirth(date: any): void {
    this.dateOfBirth = date;
  }

  onChangeExpiryDate(date: any): void {
    this.expiryDate = date;
  }

  onChangeAlienFields(): void {
    if (this.hasAlienFieldsFilled()) {
        this.hasMissingAlienField = true;
    } else {
      this.hasMissingAlienField = false;
    }
  }

  save(): void {
    if (this.employee.citizenshipType === CitizenshipType.ALIEN && this.hasAlienFieldsFilled()) {
      this.hasMissingAlienField = true;
      return;
    }

    this.employee.dateOfBirth = new Date(this.dateOfBirth.year, this.dateOfBirth.month - 1, this.dateOfBirth.day);
    this.employee.expirationDate = new Date(this.expiryDate.year, this.expiryDate.month - 1, this.expiryDate.day);

    this.employeeService.addOrUpdate(this.employee).then(result => {
      this.toastrService.success('Saved successfully');
    }, error => {
        this.toastrService.error('Failed to save...');
    });
  }

  private hasAlienFieldsFilled(): boolean {
    return this.employee.formI94AdmissionNumber === ''
      && this.employee.foreignPassportNumber === ''
      && this.employee.countryOfIssuance === '';
  }
}
