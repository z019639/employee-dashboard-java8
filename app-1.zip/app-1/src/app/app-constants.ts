export const BASE_URL = 'http://localhost:8081';
export const SOCKET_BASE_URL = 'http://localhost:8081/ws';
// export const BASE_URL = 'http://192.168.0.101:8080';
// export const SOCKET_BASE_URL = 'http://192.168.0.101:8080/ws';
export const API_BASE = 'api';
export const BASE_TOPIC = 'topic';
export const END_POINTS = {
  TEAM: 'team',
  MEMBER: 'member',
  MEMBER_LOGIN: 'login',
  UPDATE_CARDS: 'update-cards',
  DELETE_CARDS: 'delete-card',
  ADD_VOTE: 'add-vote',
  RAISE_MATCH: 'raise-match',
  APPLY_MATCH: 'apply-match',
  APPLY_PENALTY: 'apply-penalty',
  APPLY_POWER: 'apply-power',
  START_PLAYING: 'start-playing',
  PLAY: 'play',
  WEB_SOCKET: 'ws'
};
export const TOPICS = {
  TEAMS: 'teams',
  MEMBERS: 'members',
  MEMBERS_CARDS: 'member-cards'
};

export const LOCAL_STORAGE = {
  MEMBER_ID: 'memberId'
};

export const APP_CONSTANTS = {
  DEBOUNCE_TIME: 500,
  MAX_REFRESH_INTERVAL: 5000,
  COUNT_DOWN_TIME: 10000,
  RESET_CARDS_COUNT_DOWN_TIME: 5000,
  REVOKE_TIME: 5000,
  APPLY_POWER_TIME: 5
};

export const COUNT_CONSTANTS = {
  SELECTED_CARDS: 2
};
