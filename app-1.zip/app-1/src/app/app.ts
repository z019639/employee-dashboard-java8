export class MessageSubscription {
  message: any;
  topic: string;
}
